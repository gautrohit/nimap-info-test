import React from "react";
import DropdownCont from "./DropdownCont";

function Home() {
  return (
    <div className="container">
      <DropdownCont />
    </div>
  );
}

export default Home;
