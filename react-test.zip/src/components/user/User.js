import React from "react";
import Login from "./Login";

function User() {
  return (
    <div className="container">
      <Login />
    </div>
  );
}

export default User;
